# Feedback collection

User feedback is saved to local files. Every Friday, the pilot administrator exports the feedback and gives it to the project owner. Version one has no cloud synchronization; support in a later version is undecided.
