# Scope

The sample covers the first pilot version. The sources provide no production capacity, security certification conclusions, or performance test results.
