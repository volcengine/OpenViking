# Lighthouse project

Fictional tutorial sample v1. The first version runs in a pilot on an isolated network without internet access. The pilot administrator prepares an offline installation package and a local storage directory.
