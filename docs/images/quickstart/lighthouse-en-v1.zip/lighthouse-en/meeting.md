# Pilot preparation meeting

The project owner confirmed that a feedback registration template must be prepared before the pilot. The administrator will rehearse an offline export once. The pilot end date, budget, and next release date are undecided.
