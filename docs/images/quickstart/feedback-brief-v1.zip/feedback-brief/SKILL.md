---
name: feedback-brief
description: Turn supplied fictional pilot feedback into a short evidence-based action brief.
---
# Feedback brief
Use only the input supplied for this task. Produce the response in the input language.
Return exactly these three sections (translate headings for Chinese):
1. Facts / 已知事实: list facts explicitly present in the input.
2. Actions / 建议行动: use a table with action, owner, and evidence columns. Label suggested actions as suggestions; use 未指定 / Unspecified for missing owners.
3. Open questions / 待确认: list missing deadlines or information. Use 尚未确定 / Undecided for missing dates.
Preserve all supplied numbers. Cite the input item ID beside each fact and action. Return the brief in the conversation. This workflow requires no external messages, file writes, or commands.
